# Background-Remover-Flask-App-using-Python

Blog Link - https://machinelearningprojects.net/background-remover-flask-app/
