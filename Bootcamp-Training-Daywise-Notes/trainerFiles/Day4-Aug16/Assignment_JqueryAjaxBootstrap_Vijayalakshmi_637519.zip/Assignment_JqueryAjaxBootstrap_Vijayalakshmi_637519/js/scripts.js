
$(document).ready(function() {
  $('.section1_left1_btn').on('click', function() {
     
      // Fetch coffee data
      fetchCoffeeData();
  });

  function fetchCoffeeData() {
      $.ajax({
          url: 'https://api.sampleapis.com/coffee/hot', 
          method: 'GET',
          success: function(data) {
              var coffeeList = $('#coffee_list');
              var coffeeItems = $('#coffee_items');

              coffeeItems.empty(); // Clear previous list if any

              data.forEach(function(coffee) {
                  coffeeItems.append(`
                      <li>${coffee.title}</li>
                  `);
              });

              coffeeList.show(); // to Display the list
          },
          error: function(err) {
              console.error('Error fetching coffee data:', err);
          }
      });
  }
});
