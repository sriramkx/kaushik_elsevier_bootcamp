from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'  # Required for flash messages
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mydatabase.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    age = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f'<User {self.name}>'

# Route to display the form
@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

# Route to handle form submission
@app.route('/add_user', methods=['POST'])
def add_user():
    name = request.form.get('name')
    email = request.form.get('email')
    age = request.form.get('age')
    
    if not name or not email or not age:
        flash('All fields are required!')
        return redirect(url_for('index'))
    
    # Create a new User instance
    new_user = User(name=name, email=email, age=int(age))
    
    # Add and commit to the database
    db.session.add(new_user)
    db.session.commit()
    
    flash('User added successfully!')
    return redirect(url_for('view_users'))

# Route to view stored data
@app.route('/view_users', methods=['GET'])
def view_users():
    users = User.query.all()
    return render_template('view_users.html', users=users)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
