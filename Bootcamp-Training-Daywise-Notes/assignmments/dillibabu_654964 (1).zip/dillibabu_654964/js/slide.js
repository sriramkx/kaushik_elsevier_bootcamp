$(document).ready(function() {
    $('#carouselExample').on('slid.bs.carousel', function() {
      console.log('Slide transition completed');
    });
    
    $('#carouselExample').on('slide.bs.carousel', function () {
      $('.carousel-item').each(function () {
        $(this).find('img').css({
          'transition': 'transform 1s ease',
          'transform': 'scale(1.1)'
        });
      });
    });
  });