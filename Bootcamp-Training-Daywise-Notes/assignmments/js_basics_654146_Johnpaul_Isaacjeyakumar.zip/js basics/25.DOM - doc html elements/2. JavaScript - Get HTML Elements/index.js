console.log('Script Loaded');

console.log(document.getElementById("logo"));

// console.log(document.getElementsByClassName('blog-card'));

console.log(document.getElementsByTagName('h3'))