console.log('Script Loaded');

var mArr = [1, 2, 3, 4, 5];
console.log(mArr);