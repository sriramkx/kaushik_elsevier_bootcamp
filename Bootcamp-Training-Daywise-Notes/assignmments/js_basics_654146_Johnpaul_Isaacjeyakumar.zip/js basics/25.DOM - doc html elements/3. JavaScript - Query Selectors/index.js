console.log('Script Loaded');

// console.log(document.getElementById("logo"));

// console.log(document.getElementsByClassName('blog-card'));

// console.log(document.getElementsByTagName('h3'))

console.log(document.querySelectorAll('#topbar'));
console.log(document.querySelector('#topbar'));

console.log(document.querySelectorAll('.blog-card img '));
console.log(document.querySelector('.blog-card img '));