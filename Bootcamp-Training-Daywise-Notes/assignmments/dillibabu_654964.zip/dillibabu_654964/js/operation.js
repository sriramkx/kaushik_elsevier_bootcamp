
async function handleSubmit(event) {
    event.preventDefault();
    
    const countryName = document.getElementById('country').value.trim();;
    console.log(countryName);
    const request = new XMLHttpRequest();

    request.open('GET', `https://restcountries.com/v3.1/name/${countryName}`);
    request.send();
    request.addEventListener('load', function() {
        const [data] = JSON.parse(this.responseText);
        console.log(data);

        document.querySelector('table').style.display = 'table'; 
        document.querySelector('table tr:nth-child(1) td:last-child').textContent = data.name.common;
        document.querySelector('table tr:nth-child(2) td:last-child').innerHTML = `<img src="${data.flags.png}" alt="Flag" style="width:50px;">`;
        document.querySelector('table tr:nth-child(3) td:last-child').textContent = data.region;
        document.querySelector('table tr:nth-child(4) td:last-child').textContent = data.continents.join(', ');
        document.querySelector('table tr:nth-child(5) td:last-child').textContent = Object.values(data.languages).join(', ');
        document.querySelector('table tr:nth-child(6) td:last-child').textContent = Object.values(data.currencies).map(currency => currency.name).join(', ');
        document.querySelector('table tr:nth-child(7) td:last-child').textContent = data.population.toLocaleString();
    });
}
