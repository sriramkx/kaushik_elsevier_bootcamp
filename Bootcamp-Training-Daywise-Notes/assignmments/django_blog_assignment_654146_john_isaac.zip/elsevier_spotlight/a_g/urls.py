
from django.urls import path
from . import views

urlpatterns = [
   
    path('',views.a_g,name='a_g'),
    
]
