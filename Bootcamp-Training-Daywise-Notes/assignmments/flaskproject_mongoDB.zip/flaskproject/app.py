from flask import Flask,render_template, request, jsonify
from pymongo import MongoClient

app = Flask(__name__)

@app.route('/',methods=['GET'])
def hello():
    # return '<h1> HEllo World</h1>'
    url = {
        "services": "/service-details",
        "contact": "/contact",
        "form": "/form"
    }
    return render_template('index.html',url=url)

@app.route('/service-details',methods=['GET'])
def contact():
    return render_template('service-details.html')

@app.route('/form',methods=['GET'])
def form():
    return render_template('form.html')
# MongoDB connection
client = MongoClient('localhost', 27017) # Replace with your MongoDB URI
db = client['company']  # Database name
employees = db['employees']  # Collection name

@app.route('/home')
def home():
    return "Welcome to the Flask-MongoDB app!"

@app.route('/add', methods=['POST'])
def add_data_form():
    try:
        # Get form data
        name = request.form.get('name')
        age = request.form.get('age')
        
        position = request.form.get('position')
        
        # Create a dictionary with the form data
        data = {"name": name, "age": int(age), "position": position}
        
        # Insert data into MongoDB
        inserted_id = employees.insert_one(data).inserted_id
        
        # Return a success message
        return f"Data added successfully! Inserted ID: {inserted_id}", 201
    
    except Exception as e:
        return f"An error occurred: {str(e)}", 500


@app.route('/data', methods=['GET'])
def get_data():
    data = list(employees.find({}, {'_id': 0}))  # Retrieve all documents
    return jsonify(data), 200


if __name__ =='__main__':
    app.run(debug=True)